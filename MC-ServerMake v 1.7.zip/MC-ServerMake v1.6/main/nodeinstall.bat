@echo off
setlocal
:: Check for administrator rights
openfiles >nul 2>&1
if %errorlevel% neq 0 (
    echo This script must be run as an administrator.
    pause
    exit /b
)

set "NODE_VERSION=20.9.0"
set "NODE_URL=https://nodejs.org/dist/v%NODE_VERSION%/node-v%NODE_VERSION%-x64.msi"
set "NODE_INSTALLER=%TEMP%\nodejs_installer.msi"

echo Node.js installer downloading...
powershell -ExecutionPolicy Bypass -Command "try { Invoke-WebRequest -Uri '%NODE_URL%' -OutFile '%NODE_INSTALLER%' -ErrorAction Stop } catch { Write-Output 'Download failed'; exit 1 }"

:: Check for download
if not exist "%NODE_INSTALLER%" (
    echo Download failed. Please check the URL or your network connection.
    pause
    exit /b
)

echo Installing...
msiexec /i "%NODE_INSTALLER%" /quiet /norestart

echo Cleaning up...
del "%NODE_INSTALLER%"

echo Installation complete.
echo Please open a new command prompt to use node and npm.
pause
endlocal