chcp 932 >nul

pushd "%TARGET%"
call minecraftserververhenkou.bat
popd
goto :SERVER_ACTIONS
