chcp 932 >nul
cd main
ipconfig
node server.js --host 0.0.0.0
pause