cd main
call menu.bat