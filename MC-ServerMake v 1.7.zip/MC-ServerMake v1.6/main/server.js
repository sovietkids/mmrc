const express = require("express");
const { spawn } = require("child_process");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");
const iconv = require("iconv-lite");
const os = require("os");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Function to get CPU usage
let lastCpuTimes = os.cpus().map(cpu => {
    let total = 0;
    for (const type in cpu.times) {
        total += cpu.times[type];
    }
    return { total, idle: cpu.times.idle };
});

function getCpuUsage() {
    const cpus = os.cpus();
    let totalUsage = 0;

    const newCpuTimes = cpus.map(cpu => {
        let total = 0;
        for (const type in cpu.times) {
            total += cpu.times[type];
        }
        return { total, idle: cpu.times.idle };
    });

    for (let i = 0; i < cpus.length; i++) {
        const start = lastCpuTimes[i];
        const end = newCpuTimes[i];

        const idle = end.idle - start.idle;
        const total = end.total - start.total;
        const perc = 1 - idle / total;
        totalUsage += perc;
    }

    lastCpuTimes = newCpuTimes;
    return (totalUsage / cpus.length) * 100;
}

// ルートアクセスで index.html
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

io.on("connection", (socket) => {
  console.log("✅ クライアント接続");

  // Send system stats periodically
  const statsInterval = setInterval(() => {
    const freeMem = os.freemem();
    const totalMem = os.totalmem();
    const memUsage = (1 - freeMem / totalMem) * 100;
    const cpuUsage = getCpuUsage();

    socket.emit("system-stats", {
      memUsage: memUsage.toFixed(2),
      cpuUsage: cpuUsage.toFixed(2),
    });
  }, 2000);

  // コマンドプロンプトを Shift-JIS で出力
  const cmd = spawn("cmd.exe", [], { shell: true });

  cmd.stdout.on("data", (data) => {
    const sjisStr = iconv.decode(data, "cp932");
    socket.emit("cmd-output", sjisStr);
  });

  cmd.stderr.on("data", (data) => {
    const sjisStr = iconv.decode(data, "cp932");
    socket.emit("cmd-output", "ERROR: " + sjisStr);
  });

  cmd.on("close", (code) => {
    socket.emit("cmd-output", `\nプロセス終了 (コード: ${code})`);
  });

  socket.on("cmd-input", (msg) => {
    const buf = iconv.encode(msg + "\n", "cp932"); // 入力も Shift-JIS に
    cmd.stdin.write(buf);
  });

  socket.on("disconnect", () => {
    console.log("❌ クライアント切断");
    clearInterval(statsInterval);
  });
});





const PORT = process.env.PORT || 3000;

server.on('error', (err) => {
  if (err && err.code === 'EADDRINUSE') {
    console.error(`ポート ${PORT} は既に使用されています。別のプロセスが起動している可能性があります。`);
    process.exit(1);
  } else {
    console.error('サーバーエラー:', err);
    process.exit(1);
  }
});

server.listen(PORT, () => console.log(`🌐 http://localhost:${PORT} で編集サーバー起動中`));
