cd main
npm i
cd ..
echo 作業が終了しました。
call start.bat